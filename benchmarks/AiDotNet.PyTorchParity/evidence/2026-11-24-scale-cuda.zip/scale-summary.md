| Model | Device | Dataset | Samples per launch | AiDotNet samples/s | PyTorch samples/s (configuration) | PyTorch time ÷ AiDotNet time, median (range) | Final test accuracy, AiDotNet / PyTorch |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| cnn | cuda | emnist-digits | 720,000 | 58,313 | 25,008 (`torch-cudagraphs-fused`) | 2.33 (2.33–2.35) | 99.16% / 99.19% |
| cnn | cuda | synth-mnist | 1,000,000 | 58,246 | 24,835 (`torch-cudagraphs-fused`) | 2.35 (2.32–2.35) | 98.13% / 99.00% |
| densenet121 | cuda | cinic10 | 539,904 | 315 | 330 (`torch-cudagraphs-fused`) | 0.95 (0.95–0.95) | 76.81% / 76.90% |
| densenet121 | cuda | synth-rgb32 | 1,000,000 | 317 | 330 (`torch-cudagraphs-fused`) | 0.96 (0.96–0.96) | 99.98% / 99.96% |
| gru | cuda | emnist-seq32 | 720,000 | 114,650 | 15,085 (`torch-cudagraphs-fused`) | 8.21 (7.17–8.53) | 98.92% / 98.87% |
| gru | cuda | synth-seq32 | 1,000,000 | 103,205 | 14,774 (`torch-cudagraphs-fused`) | 6.34 (1.89–13.66) | 99.59% / 99.52% |
| lstm | cuda | emnist-seq32 | 720,000 | 94,473 | 15,254 (`torch-compile-fused`) | 6.15 (5.67–7.10) | 98.80% / 98.80% |
| lstm | cuda | synth-seq32 | 1,000,000 | 80,707 | 17,189 (`torch-compile-fused`) | 4.66 (4.60–10.80) | 99.62% / 99.67% |
| mlp | cuda | emnist-digits | 720,000 | 150,635 | 23,884 (`torch-cudagraphs-fused`) | 6.17 (6.01–7.51) | 98.92% / 98.89% |
| mlp | cuda | synth-mnist | 1,000,000 | 120,697 | 23,173 (`torch-cudagraphs-fused`) | 5.18 (4.83–11.52) | 99.99% / 100.00% |
| mobilenetv2 | cuda | cinic10 | 539,904 | 4,753 | 5,735 (`torch-cudagraphs-fused`) | 0.83 (0.82–0.91) | 56.32% / 58.52% |
| mobilenetv2 | cuda | synth-rgb32 | 1,000,000 | 4,753 | 5,789 (`torch-cudagraphs-fused`) | 0.82 (0.82–0.93) | 99.93% / 99.91% |
| resnet18 | cuda | cinic10 | 539,904 | 4,002 | 837 (`torch-cudagraphs-fused`) | 4.77 (4.73–4.83) | 64.82% / 65.50% |
| resnet18 | cuda | synth-rgb32 | 1,000,000 | 4,034 | 834 (`torch-cudagraphs-fused`) | 4.84 (4.75–4.87) | 99.99% / 99.99% |
| resnet50 | cuda | cinic10 | 539,904 | 1,854 | 670 (`torch-cudagraphs-fused`) | 2.76 (2.76–2.77) | 61.29% / 59.72% |
| resnet50 | cuda | synth-rgb32 | 1,000,000 | 1,850 | 670 (`torch-cudagraphs-fused`) | 2.76 (2.75–2.77) | 99.92% / 99.92% |
| transformer | cuda | emnist-seq32 | 720,000 | 39,729 | 19,902 (`torch-cudagraphs-fused`) | 2.00 (1.96–2.04) | 94.66% / 94.83% |
| transformer | cuda | synth-seq32 | 1,000,000 | 39,764 | 19,653 (`torch-cudagraphs-fused`) | 2.03 (2.00–2.08) | 88.75% / 89.36% |
| vgg11 | cuda | cinic10 | 539,904 | 2,071 | 1,693 (`torch-cudagraphs-fused`) | 1.22 (1.22–1.22) | 62.39% / 63.71% |
| vgg11 | cuda | synth-rgb32 | 1,000,000 | 2,088 | 1,692 (`torch-cudagraphs-fused`) | 1.23 (1.23–1.23) | 9.82% / 9.82% |
| vit | cuda | cinic10 | 539,904 | 1,328 | 1,328 (`torch-cudagraphs-fused`) | 1.00 (1.00–1.00) | 10.00% / 48.85% |
| vit | cuda | synth-rgb32 | 1,000,000 | 1,329 | 1,327 (`torch-cudagraphs-fused`) | 1.00 (1.00–1.00) | 9.82% / 99.73% |
