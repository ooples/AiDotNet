param(
    [switch]$Smoke,
    [int]$Launches = 2,
    [string[]]$Models = @('mlp','lstm','transformer','cnn','resnet18','resnet50','vgg11','vit','gru','mobilenetv2','densenet121'),
    [string[]]$Devices = @('cuda','cpu'),
    [switch]$NonInteractive
)
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
trap {
    Write-Host $_ -ForegroundColor Red
    if ($runLock) { try { $runLock.ReleaseMutex() } catch {}; $runLock.Dispose() }
    if (-not $NonInteractive) { Read-Host 'Press Enter to close' }
    exit 1
}
$runLock = [System.Threading.Mutex]::new($false,'Local\AiDotNetRedditBenchmark20261119')
try { $lockAcquired = $runLock.WaitOne(0) }
catch [System.Threading.AbandonedMutexException] { $lockAcquired = $true }
if (-not $lockAcquired) { throw 'Another integration benchmark is already running; refusing overlapping measurements.' }
if ($Launches -lt 1) { throw 'Launches must be positive.' }
if (-not (Get-Command cl -ErrorAction SilentlyContinue)) {
    $vswhere = 'C:/Program Files (x86)/Microsoft Visual Studio/Installer/vswhere.exe'
    $vsRoot = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if (-not $vsRoot) { throw 'PyTorch CPU torch.compile needs the Visual Studio C++ build tools.' }
    & "$vsRoot/Common7/Tools/Launch-VsDevShell.ps1" -SkipAutomaticLocation -Arch amd64 -HostArch amd64 | Out-Null
    if (-not (Get-Command cl -ErrorAction SilentlyContinue)) { throw 'MSVC environment initialization did not expose cl.exe.' }
}
$runRoot = $PSScriptRoot
$env:TORCHINDUCTOR_CACHE_DIR = "$runRoot/torchinductor-cache"
$env:TRITON_CACHE_DIR = "$runRoot/triton-cache"
$manifest = Get-Content -Raw -LiteralPath "$runRoot/integration-manifest.json" | ConvertFrom-Json
foreach ($repo in $manifest.repositories) {
    $head = git -C $repo.worktree rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $head -ne $repo.head) { throw "Source changed: $($repo.repository). Rebuild and update the manifest first." }
    $dirty = git -C $repo.worktree status --porcelain --untracked-files=no
    if ($dirty) { throw "Uncommitted source changes: $($repo.repository)" }
}
$aiRoot = ($manifest.repositories | Where-Object repository -eq 'ooples/AiDotNet').worktree
$bin = "$aiRoot/benchmarks/AiDotNet.PyTorchParity/bin/Release/net10.0"
$exe = "$bin/AiDotNet.PyTorchParity.exe"
$python = 'C:/path/to/benchmark-host/torchbench-venv/Scripts/python.exe'
$pyRoot = "$aiRoot/benchmarks/AiDotNet.PyTorchParity/pytorch"
$expected = Get-Content -Raw -LiteralPath "$runRoot/build-fingerprints.json" | ConvertFrom-Json
foreach ($file in $expected) {
    if ((Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash -ne $file.sha256) { throw "Binary changed: $($file.path)" }
}
$sourceFiles = Get-Content -Raw -LiteralPath "$runRoot/source-fingerprints.json" | ConvertFrom-Json
foreach ($file in $sourceFiles) {
    if ((Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash -ne $file.sha256) { throw "Benchmark source changed: $($file.path)" }
}
$env:AIDOTNET_CPU_THREADS = '8'
$env:AIDOTNET_BLAS_THREADS = '8'
$env:OMP_NUM_THREADS = '8'
$env:MKL_NUM_THREADS = '8'
$env:OPENBLAS_NUM_THREADS = '8'
$env:AIDOTNET_FUSED_DIAG = '1'
if ($Smoke) { $Models = @('mlp','cnn','lstm','transformer'); $Launches = 1 }
$mode = if ($Smoke) { 'smoke' } else { 'full' }
$out = Join-Path $runRoot "$mode-$([DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ'))"
New-Item -ItemType Directory -Path $out | Out-Null
Copy-Item -LiteralPath "$runRoot/integration-manifest.json", "$runRoot/build-fingerprints.json", "$runRoot/source-fingerprints.json" -Destination $out
@{smoke=[bool]$Smoke;launches=$Launches;models=$Models;devices=$Devices;threads=8;startedUtc=[DateTime]::UtcNow.ToString('o')} |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$out/protocol.json"
& nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv | Set-Content -LiteralPath "$out/gpu.csv"
& $python -c 'import torch,torchvision,sys; print(sys.version); print(torch.__version__,torchvision.__version__,torch.version.cuda)' > "$out/python-environment.txt" 2>&1
Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json | Set-Content "$out/cpu.json"
$epochs = if ($Smoke) { 2 } else { 3 }
$batches = if ($Smoke) { 2 } else { 20 }
$iterations = if ($Smoke) { 3 } else { 100 }
$warmup = if ($Smoke) { 1 } else { 10 }
$common = @('--epochs', "$epochs", '--train-batches', "$batches", '--batch-size', '64', '--inference-iterations', "$iterations", '--warmup-iterations', "$warmup", '--inference-batches', '1,8,16', '--seed', '1234')
$failures = @()
foreach ($launch in 1..$Launches) {
    foreach ($device in $Devices) {
        if ($device -notin @('cpu','cuda')) { throw "Unsupported device: $device" }
        foreach ($model in $Models) {
            foreach ($side in @('aidotnet','torch-compile')) {
                $tag = "$side-$launch-$device-$model"
                $report = "$out/$tag.json"
                $log = "$out/$tag.log"
                $start = [DateTime]::UtcNow
                Write-Host "[$($start.ToString('HH:mm:ss'))] $tag"
                if ($side -eq 'aidotnet') {
                    & $exe --models $model --device $device @common --output $report > $log 2>&1
                } else {
                    Push-Location $pyRoot
                    try { & $python benchmark.py --models $model --device $device --threads 8 --compile @common --output $report > $log 2>&1 }
                    finally { Pop-Location }
                }
                $code = $LASTEXITCODE
                if ($code -ne 0 -or -not (Test-Path -LiteralPath $report)) { $failures += $tag }
                @{tag=$tag;exitCode=$code;startedUtc=$start.ToString('o');finishedUtc=[DateTime]::UtcNow.ToString('o')} |
                    ConvertTo-Json | Set-Content -LiteralPath "$out/$tag.receipt.json"
            }
            if ((Test-Path "$out/aidotnet-$launch-$device-$model.json") -and (Test-Path "$out/torch-compile-$launch-$device-$model.json")) {
                & $python "$pyRoot/compare.py" "$out/aidotnet-$launch-$device-$model.json" "$out/torch-compile-$launch-$device-$model.json" > "$out/comparison-$launch-$device-$model.txt" 2>&1
                if ($LASTEXITCODE -ne 0) { $failures += "comparison-$launch-$device-$model" }
            }
        }
    }
}
@{finishedUtc=[DateTime]::UtcNow.ToString('o');failures=$failures;smoke=[bool]$Smoke} |
    ConvertTo-Json | Set-Content -LiteralPath "$out/completion.json"
Write-Host "Results: $out"
& $python "$runRoot/Summarize-Benchmarks.py" $out
if ($failures.Count) { throw "$($failures.Count) benchmark processes failed. Inspect completion.json and their logs." }
$runLock.ReleaseMutex()
$runLock.Dispose()
