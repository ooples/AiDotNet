| Model | Device | Dataset | Samples per launch | AiDotNet samples/s | PyTorch samples/s (configuration) | PyTorch time ÷ AiDotNet time, median (range) | Final test accuracy, AiDotNet / PyTorch | Flags |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| cnn | cpu | emnist-digits | 720,000 | 11,775 | 6,241 (`torch-compile-fused`) | 1.89 (1.85–1.91) | 99.15% / 99.23% |  |
| cnn | cpu | synth-mnist | 1,000,000 | 11,105 | 5,916 (`torch-compile-fused`) | 1.88 (1.85–1.89) | 98.27% / 99.20% |  |
| densenet121 | cpu | cinic10 | 179,968 | 34 | 26 (`torch-compile`) | 1.31 (1.29–1.35) | 64.91% / 62.02% |  |
| gru | cpu | emnist-seq32 | 720,000 | 16,149 | 7,985 (`torch-compile-fused-rnn`) | 2.02 (2.00–2.03) | 98.89% / 98.88% | ai-launches-disagree |
| gru | cpu | synth-seq32 | 1,000,000 | 16,616 | 7,992 (`torch-compile-fused-rnn`) | 2.08 (2.00–2.18) | 99.48% / 99.52% | ai-launches-disagree |
| lstm | cpu | emnist-seq32 | 720,000 | 30,436 | 10,234 (`torch-compile-fused`) | 2.94 (2.88–2.98) | 98.84% / 98.83% |  |
| lstm | cpu | synth-seq32 | 1,000,000 | 29,337 | 10,077 (`torch-compile-fused`) | 2.81 (2.56–3.04) | 99.62% / 99.78% |  |
| mlp | cpu | emnist-digits | 720,000 | 62,744 | 18,445 (`torch-compile-fused`) | 3.40 (3.13–3.43) | 98.77% / 98.88% |  |
| mlp | cpu | synth-mnist | 1,000,000 | 59,152 | 18,019 (`torch-compile-fused`) | 3.26 (3.13–3.64) | 99.99% / 100.00% |  |
| mobilenetv2 | cpu | cinic10 | 179,968 | 548 | 273 (`torch-compile-fused`) | 2.01 (1.99–2.02) | 45.28% / 47.85% |  |
| resnet18 | cpu | cinic10 | 179,968 | 732 | 139 (`torch-compile-fused`) | 5.27 (5.09–5.47) | 54.65% / 55.36% |  |
| resnet50 | cpu | cinic10 | 179,968 | 287 | 91 (`torch-compile-fused`) | 3.19 (3.05–3.27) | 42.85% / 45.64% |  |
| transformer | cpu | emnist-seq32 | 720,000 | 11,448 | 4,120 (`torch-compile-fused`) | 2.78 (2.77–2.78) | 94.44% / 94.85% |  |
| transformer | cpu | synth-seq32 | 1,000,000 | 11,377 | 4,064 (`torch-compile-fused`) | 2.75 (2.74–2.86) | 89.03% / 89.75% |  |
| vgg11 | cpu | cinic10 | 179,968 | 158 | 111 (`torch-compile-fused`) | 1.43 (1.39–1.46) | 54.02% / 53.30% |  |
| vit | cpu | cinic10 | 179,968 | 192 | 137 (`torch-compile-fused`) | 1.40 (1.38–1.41) | 41.59% / 42.52% | ai-launches-disagree |
