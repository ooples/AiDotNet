| Model | Device | Dataset | Samples per launch | AiDotNet samples/s | PyTorch samples/s (configuration) | PyTorch time ÷ AiDotNet time, median (range) | Final test accuracy, AiDotNet / PyTorch | Flags |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| vit | cuda | cinic10 | 539,904 | 1,330 | 1,328 (`torch-cudagraphs-fused`) | 1.00 (1.00–1.00) | 45.09% / 48.38% |  |
| vit | cuda | synth-rgb32 | 1,000,000 | 1,329 | 1,327 (`torch-cudagraphs-fused`) | 1.00 (1.00–1.00) | 99.60% / 99.60% |  |
