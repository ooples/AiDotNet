**CUDA**: PyTorch time ÷ AiDotNet time, median of launches (range of launches). Above 1 means AiDotNet took less time. ⚑ marks a row with a flag in summary.csv.

| Model | Training, batch 64 | Inference, batch 1 | Inference, batch 8 | Inference, batch 16 |
| --- | ---: | ---: | ---: | ---: |
| vit | 1.02 (1.02–1.02) ⚑ | 0.58 (0.57–0.71) ⚑ | 0.98 (0.74–1.08) ⚑ | 0.91 (0.89–0.95) ⚑ |
