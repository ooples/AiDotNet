Moved here on 2026-11-20 at 20:59 UTC because the laptop switched to battery during this process (its receipt is flagged "battery").
The run stopped before the next process and was continued with run_matrix.py --resume on AC power, which measured this process again.
