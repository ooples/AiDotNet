#!/usr/bin/env bash
# Fresh PyTorch parity run, matching the PR #2381 protocol:
# 11 families x {AiDotNet, torch.compile} (compiled PyTorch only, per user 2026-11-13) x {cuda, cpu}, 2 launches,
# one process per model so a single failing row does not lose the rest.
# AiDotNet = origin/master 8e1066a745 built with -p:UseLocalTensors=true against
# AiDotNet.Tensors origin/main d9dd73f4c. Rows whose JSON already exists are skipped.
set -u
OUT=/path/to/benchmark-host/parity-2026-11-13
EXE=/path/to/benchmark-host/source/repos/AiDotNet-bench/benchmarks/AiDotNet.PyTorchParity/bin/Release/net10.0/AiDotNet.PyTorchParity.exe
PY=/path/to/benchmark-host/torchbench-venv/Scripts/python.exe
PYDIR=/path/to/benchmark-host/source/repos/AiDotNet-bench/benchmarks/AiDotNet.PyTorchParity/pytorch
MODELS="mlp lstm transformer cnn resnet18 resnet50 vgg11 vit gru mobilenetv2"
LAST="densenet121"  # heaviest on memory; run after everything else (user, 2026-11-13)
COMMON="--epochs 3 --train-batches 20 --batch-size 64 --inference-iterations 100 --warmup-iterations 10 --inference-batches 1,8,16"
export AIDOTNET_CPU_THREADS=8

run() { # side tag cmd...
  local side=$1 tag=$2; shift 2
  [ -s "$OUT/$side-$tag.json" ] && return
  echo "[$(date +%T)] $side $tag"
  "$@" --output "$OUT/$side-$tag.json" > "$OUT/$side-$tag.log" 2>&1 || echo "  FAILED $side $tag (exit $?)"
}

for launch in 1 2; do
  for dev in cuda cpu; do
    for m in $MODELS; do
      tag="$launch-$dev-$m"
      run aidotnet "$tag" "$EXE" --models "$m" --device "$dev" $COMMON
      cd "$PYDIR"
      run torch-compile "$tag" "$PY" benchmark.py --models "$m" --device "$dev" --threads 8 --compile $COMMON
    done
  done
done
for launch in 1 2; do
  for dev in cuda cpu; do
    m=$LAST; tag="$launch-$dev-$m"
    run aidotnet "$tag" "$EXE" --models "$m" --device "$dev" $COMMON
    cd "$PYDIR"
    run torch-compile "$tag" "$PY" benchmark.py --models "$m" --device "$dev" --threads 8 --compile $COMMON
  done
done
echo "[$(date +%T)] DONE"
