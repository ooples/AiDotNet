**CPU**: PyTorch time ÷ AiDotNet time, median of launches (range of launches). Above 1 means AiDotNet took less time. ⚑ marks a row with a flag in summary.csv.

| Model | Training, batch 64 | Inference, batch 1 | Inference, batch 8 | Inference, batch 16 |
| --- | ---: | ---: | ---: | ---: |
| vit | 1.40 (1.23–1.41) ⚑ | 1.42 (1.07–1.44) ⚑ | 1.28 (0.92–1.30) ⚑ | 1.42 (1.29–1.46) ⚑ |
