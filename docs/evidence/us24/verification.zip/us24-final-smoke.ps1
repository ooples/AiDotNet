$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath (Split-Path -Parent $PSScriptRoot)
$cli = 'tools/AiDotNet.Evolve.Cli/bin/Release/net10.0/aidotnet-evolve.dll'
$stem = 'TestResults/us24-cli/final-93b6111-v2'
$config = '.local/us24-final-smoke.yaml'
foreach ($suffix in @('-run', '-record', '-resume-record', '-export', '-comparison')) {
    if (Test-Path -LiteralPath ($stem + $suffix)) { throw 'Refusing to overwrite prior final-gate evidence.' }
}
& dotnet $cli run --config $config --record "$stem-record" --include-source --session us24final93 --json > "$stem-run.stdout.json" 2> "$stem-run.stderr.log"
if ($LASTEXITCODE -ne 0) { throw "Run failed: $LASTEXITCODE" }
$before = @{}
Get-ChildItem -LiteralPath "$stem-run/checkpoints" -Directory | Where-Object { $_.Name -match '^checkpoint_[0-9]+$' } | Get-ChildItem -File |
    ForEach-Object { $before[$_.FullName] = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash }
& dotnet $cli run --config $config --resume --record "$stem-resume-record" --include-source --session us24final93 --json > "$stem-resume.stdout.json" 2> "$stem-resume.stderr.log"
if ($LASTEXITCODE -ne 0) { throw "Resume failed: $LASTEXITCODE" }
foreach ($path in $before.Keys) {
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $before[$path]) { throw 'Prior checkpoint output changed.' }
}
& dotnet $cli inspect-record --record "$stem-resume-record" > "$stem-inspect.json" 2> "$stem-inspect.stderr.log"
if ($LASTEXITCODE -ne 0) { throw "Inspect failed: $LASTEXITCODE" }
& dotnet $cli export --record "$stem-resume-record" --out "$stem-export" > "$stem-export.stdout.log" 2> "$stem-export.stderr.log"
if ($LASTEXITCODE -ne 0) { throw "Export failed: $LASTEXITCODE" }
& dotnet $cli compare --left "$stem-record" --right "$stem-resume-record" --out "$stem-comparison" > "$stem-compare.json" 2> "$stem-compare.stderr.log"
if ($LASTEXITCODE -ne 0) { throw "Compare failed: $LASTEXITCODE" }
$original = Get-FileHash -LiteralPath "$stem-record/program.txt" -Algorithm SHA256
foreach ($suffix in @('-resume-record', '-export', '-comparison/left', '-comparison/right')) {
    if ((Get-FileHash -LiteralPath "$stem$suffix/program.txt" -Algorithm SHA256).Hash -ne $original.Hash) { throw 'Exported source differs.' }
}
$run = Get-Content -LiteralPath "$stem-record/result.json" -Raw | ConvertFrom-Json
$resume = Get-Content -LiteralPath "$stem-resume.stdout.json" -Raw | ConvertFrom-Json
$inspection = Get-Content -LiteralPath "$stem-resume-record/result.json" -Raw | ConvertFrom-Json
$configuration = Get-Content -LiteralPath "$stem-record/configuration.json" -Raw | ConvertFrom-Json
if ($run.Inspection.SegmentStatuses.Completed -ne 1 -or $run.Inspection.SegmentStatuses.Rejected -ne 1) { throw 'Wrong candidate was not gated.' }
if ($resume.EvaluationAttempts -ne 2 -or $inspection.Inspection.SegmentEvaluationAttempts -ne 0) { throw 'Lifetime/segment accounting mismatch.' }
if ($null -eq $run.Inspection.Runtime -or $run.Inspection.Runtime.ChatCalls -ne 0 -or $run.Inspection.Runtime.QueuedExecutions -ne 0) { throw 'Missing runtime telemetry.' }
if ($configuration.SchemaVersion -ne 2 -or $configuration.Configuration.Evolution.EnableEvaluationCache -ne $false) { throw 'Configuration template/cache mismatch.' }
if ((Get-ChildItem -LiteralPath "$stem-model-queue" -File -Recurse | Measure-Object).Count -ne 0) { throw 'Unexpected model request.' }
[pscustomobject]@{
    Passed = $true
    PriorSnapshotFilesUnchanged = $before.Count
    PriorSha256 = $before
    ExactSourceSha256 = $original.Hash
    LifetimeEvaluationAttempts = $resume.EvaluationAttempts
    ResumeSegmentEvaluationAttempts = $inspection.Inspection.SegmentEvaluationAttempts
    LiveRuntime = $run.Inspection.Runtime
    ConfigurationSchemaVersion = $configuration.SchemaVersion
    ManualModelRequests = 0
    Scope = 'Authored Python/script seeds, new cache policy, bounded preflight, same-budget resume, telemetry and exact export; no paid model calls or superiority claim.'
} | ConvertTo-Json -Depth 6
